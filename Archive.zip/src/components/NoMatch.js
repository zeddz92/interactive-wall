import React, {Component} from 'react';

function NoMatch(props) {
    return (
        <div>
            <h1>Woops, 404</h1>
            <h3>The page you were looking for could not be found</h3>
        </div>
    )
}

export default NoMatch;